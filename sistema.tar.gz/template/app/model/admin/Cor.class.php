<?php
/**
 * Active Record que permite acessar os dados complementares
 * @author  Marcos de Souza
 */
class Cor extends TRecord
{
    const TABLENAME = 'cad_cor';
    const PRIMARYKEY= 'id';
    const IDPOLICY =  'max'; // {max, serial}
    
    private $usuario;
    //private $nome;
    

    /**
     * Constructor method
     */
    public function __construct($id = NULL)
    {
        parent::__construct($id);
        parent::addAttribute('descricao');   
  
     
       
    }
    public function set_Usuario(SystemUser $object)
    {
        $this->usuario = $object;
        //$this->codUsuario = $object->codUsuario;
    }
    public static function get_Usuario()
    {
        // loads the associated object
        if (empty($this->usuario))
            $this->usuario = new SystemUser($this->id);
    
        // returns the associated object
        return $this->usuario;
    }
   
    
  



}
?>