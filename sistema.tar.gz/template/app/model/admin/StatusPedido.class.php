<?php
/**
 * Active Record que permite acessar os dados complementares
 * @author  Marcos de Souza
 */
class StatusPedido extends TRecord
{
    const TABLENAME = 'cad_status_pedido';
    const PRIMARYKEY= 'id';
    const IDPOLICY =  'max'; // {max, serial}
    
   
    

    /**
     * Constructor method
     */
    public function __construct($id = NULL)
    {
        parent::__construct($id);
        parent::addAttribute('status'); 
        parent::addAttribute('descricao'); 
     
       
    } 
   


}
?>