<?php
/**
 * Active Record que permite acessar os dados complementares
 * @author  Marcos de Souza
 */
class Pedido extends TRecord
{
    const TABLENAME = 'cad_pedido';
    const PRIMARYKEY= 'id';
    const IDPOLICY =  'max'; // {max, serial}
    
    private $usuario;
    
    //private $nome;
    

    /**
     * Constructor method
     */
    public function __construct($id = NULL)
    {
        parent::__construct($id);
        parent::addAttribute('id_cliente');          
        parent::addAttribute('cod_pedido');  
        parent::addAttribute('qdt_pecas');  
        parent::addAttribute('id_status_pedido');   
       
    }
    public function get_cliente()
    {
        // loads the associated object
        return Cliente::find($this->id_cliente);
    }


    public function get_cor()
    {
        // loads the associated object
        return Cor::find($this->id_cor);
    }

    
   public function get_statuspedido()
   {
        // loads the associated object
       return StatusPedido::find($this->id_status_pedido);
   }

   
/*
    public function get_status_pedido()
    {
        // loads the associated object
        if (empty($this->status))
            $this->status = new StatusPedido($this->id_status_pedido);
    
        // returns the associated object
        return $this->status;
    }
*/
    
   
  
    
  



}
?>