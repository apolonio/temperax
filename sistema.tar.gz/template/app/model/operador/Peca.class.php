<?php
/**
 * Active Record que permite acessar os dados complementares
 * @author  Marcos de Souza
 */
class Peca extends TRecord
{
    const TABLENAME = 'cad_peca';
    const PRIMARYKEY= 'id';
    const IDPOLICY =  'max'; // {max, serial}
    
   
    
    //private $nome;
    

    /**
     * Constructor method
     */
    public function __construct($id = NULL)
    {
        parent::__construct($id);
        parent::addAttribute('id_status_peca');  
        parent::addAttribute('id_pedido');  
        parent::addAttribute('tipo_peca');
        parent::addAttribute('cod_peca'); 
        parent::addAttribute('id_cor'); 
        parent::addAttribute('espessura'); 
        parent::addAttribute('data_evento');  
        parent::addAttribute('hora');  
        parent::addAttribute('descricao');   
       
    }
    public function get_statuspeca()
    {
        // loads the associated object
        return StatusPeca::find($this->id_status_peca);
    }


    public function get_pedido()
    {
        // loads the associated object
        return Pedido::find($this->id_pedido);
    }

    public function get_cor()
    {
        // loads the associated object
        return Cor::find($this->id_cor);
    }
    
   public function get_statuspedido()
   {
        // loads the associated object
       return StatusPedido::find($this->id_status_pedido);
   }

   
/*
    public function get_status_pedido()
    {
        // loads the associated object
        if (empty($this->status))
            $this->status = new StatusPedido($this->id_status_pedido);
    
        // returns the associated object
        return $this->status;
    }
*/
    
   
  
    
  



}
?>