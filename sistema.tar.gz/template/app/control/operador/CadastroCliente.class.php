<?php
/**
 * StandardFormDataGridView
 *
 * @version    1.0
 * @package    samples
 * @subpackage tutor
 * @author     Pablo Dall'Oglio
 * @copyright  Copyright (c) 2006 Adianti Solutions Ltd. (http://www.adianti.com.br)
 * @license    http://www.adianti.com.br/framework-license
 */
class CadastroCliente extends TPage
{
    protected $form;      // form
    protected $datagrid;  // datagrid
    protected $loaded;
    protected $pageNavigation;  // pagination component
    
    // trait with onSave, onEdit, onDelete, onReload, onSearch...
    use Adianti\Base\AdiantiStandardFormListTrait;
    
    /**
     * Class constructor
     * Creates the page, the form and the listing
     */
    public function __construct()
    {
        parent::__construct();
        
        $this->setDatabase('sample'); // define the database
        $this->setActiveRecord('Cliente'); // define the Active Record
        $this->setDefaultOrder('id', 'asc'); // define the default order
        $this->setLimit(-1); // turn off limit for datagrid
        
        // create the form
        $this->form = new BootstrapFormBuilder('form_cliente');
        $this->form->setFormTitle(('Cadastro de Clientes'));
        
        // create the form fields
        $id     = new TEntry('id');
        $nome   = new TEntry('nome');
        $cnpj   = new TEntry('cnpj');
        $responsavel   = new TEntry('responsavel');
        $email   = new TEntry('email');
        $telefone1   = new TEntry('telefone1');
        $telefone2   = new TEntry('telefone2');
        $endereco   = new TEntry('endereco');
        $uf   = new TEntry('uf');
        $cidade   = new TEntry('cidade');

        
        // add the form fields
        $this->form->addFields( [new TLabel('ID')],    [$id] );
        $this->form->addFields( [new TLabel('Nome da empresa', 'red')],  [$nome] );
        $this->form->addFields( [new TLabel('CNPJ', 'blue')],  [$cnpj] );
        $this->form->addFields( [new TLabel('Responsável', 'blue')],  [$responsavel] );
        $this->form->addFields( [new TLabel('E-mail', 'blue')],  [$email] );
        $this->form->addFields( [new TLabel('Telefone(1)', 'blue')],  [$telefone1] );
        $this->form->addFields( [new TLabel('Telefone(2)', 'blue')],  [$telefone2] );
        $this->form->addFields( [new TLabel('Endereço', 'red')],  [$endereco] );
        $this->form->addFields( [new TLabel('UF', 'red')],  [$uf] );
        $this->form->addFields( [new TLabel('Cidade', 'blue')],  [$cidade] );
        
        $nome->addValidation('nome', new TRequiredValidator);
        $endereco->addValidation('endereco', new TRequiredValidator);
        $uf->addValidation('uf', new TRequiredValidator);
        
        // define the form actions
        $this->form->addAction( 'Save', new TAction([$this, 'onSave']), 'fa:save green');
        $this->form->addActionLink( 'Clear',new TAction([$this, 'onClear']), 'fa:eraser red');
        
        // make id not editable
        $id->setEditable(FALSE);
        
        // create the datagrid
        $this->datagrid = new BootstrapDatagridWrapper(new TDataGrid);
        $this->datagrid->width = '100%';
        
        // add the columns
        $col_id    = new TDataGridColumn('id', 'Id', 'right', '5%');
        $col_nome  = new TDataGridColumn('nome', 'Nome da empresa', 'left', '15%');
        $col_cnpj  = new TDataGridColumn('cnpj', 'CNPJ', 'left', '10%');
        $col_responsavel  = new TDataGridColumn('responsavel', 'Responsável', 'left', '10%');
        $col_email  = new TDataGridColumn('email', 'E-mail', 'left', '10%');
        $col_telefone1  = new TDataGridColumn('telefone1', 'Telefone(1)', 'left', '5%');
        $col_telefone2  = new TDataGridColumn('telefone2', 'Telefone(2)', 'left', '5%');
        $col_endereco  = new TDataGridColumn('endereco', 'Endereço', 'left', '25%');
        $col_uf  = new TDataGridColumn('uf', 'UF', 'left', '5%');
        $col_cidade  = new TDataGridColumn('cidade', 'Cidade', 'left', '10%');

        
        $this->datagrid->addColumn($col_id);
        $this->datagrid->addColumn($col_nome);
        $this->datagrid->addColumn($col_cnpj);
        $this->datagrid->addColumn($col_responsavel);
        $this->datagrid->addColumn($col_email);
        $this->datagrid->addColumn($col_telefone1);
        $this->datagrid->addColumn($col_telefone2);
        $this->datagrid->addColumn($col_endereco);
        $this->datagrid->addColumn($col_uf);
        $this->datagrid->addColumn($col_cidade);
      

        
        $col_id->setAction( new TAction([$this, 'onReload']),   ['order' => 'id']);
        //$col_nome->setAction( new TAction([$this, 'onReload']), ['order' => 'nome']);
        //$col_cnpj->setAction( new TAction([$this, 'onReload']), ['order' => 'cnpj']);
        //$col_responsavel->setAction( new TAction([$this, 'onReload']), ['order' => 'responsavel']);
        //$col_email->setAction( new TAction([$this, 'onReload']), ['order' => 'email']);
        //$col_telefone1->setAction( new TAction([$this, 'onReload']), ['order' => 'telefone1']);
        //$col_telefone2->setAction( new TAction([$this, 'onReload']), ['order' => 'telefone2']);
        //$col_endereco->setAction( new TAction([$this, 'onReload']), ['order' => 'endereco']);
        //$col_uf->setAction( new TAction([$this, 'onReload']), ['order' => 'uf']);
        //$col_cidade->setAction( new TAction([$this, 'onReload']), ['order' => 'cidade']);
        
        // define row actions
        $action1 = new TDataGridAction([$this, 'onEdit'],   ['key' => '{id}'] );
        $action2 = new TDataGridAction([$this, 'onDelete'], ['key' => '{id}'] );
        
        $this->datagrid->addAction($action1, 'Edit',   'far:edit blue');
        $this->datagrid->addAction($action2, 'Delete', 'far:trash-alt red');
        
        // create the datagrid model
        $this->datagrid->createModel();
        
        // wrap objects inside a table
        $vbox = new TVBox;
        $vbox->style = 'width: 100%';
        $vbox->add(new TXMLBreadCrumb('menu.xml', __CLASS__));
        $vbox->add($this->form);
        $vbox->add(TPanelGroup::pack('', $this->datagrid));
        
        // pack the table inside the page
        parent::add($vbox);
    }
}