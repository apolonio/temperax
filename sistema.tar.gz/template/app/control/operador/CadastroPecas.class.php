<?php
/**
 * StandardFormDataGridView
 *
 * @version    1.0
 * @package    samples
 * @subpackage tutor
 * @author     Pablo Dall'Oglio
 * @copyright  Copyright (c) 2006 Adianti Solutions Ltd. (http://www.adianti.com.br)
 * @license    http://www.adianti.com.br/framework-license
 */
class CadastroPecas extends TPage
{
    protected $form;      // form
    protected $datagrid;  // datagrid
    protected $loaded;
    protected $pageNavigation;  // pagination component
    
    // trait with onSave, onEdit, onDelete, onReload, onSearch...
    use Adianti\Base\AdiantiStandardFormListTrait;
    
    /**
     * Class constructor
     * Creates the page, the form and the listing
     */
    public function __construct()
    {
        parent::__construct();
        
        $this->setDatabase('sample'); // define the database
        $this->setActiveRecord('Peca'); // define the Active Record
        $this->setDefaultOrder('id', 'asc'); // define the default order
        $this->setLimit(-1); // turn off limit for datagrid
        
        // create the form
        $this->form = new BootstrapFormBuilder('form_pecas');
        $this->form->setFormTitle(('Cadastro de Peças'));
        
        // create the form fields
        $id     = new TEntry('id');
        $id_status_peca   = new TDBCombo('id_status_peca', 'sample', 'StatusPeca', 'id', 'status');       
        $id_pedido   = new TDBCombo('id_pedido', 'sample', 'Pedido', 'id', 'cod_pedido');
        $tipo_peca   = new TEntry('tipo_peca');
        $cod_peca   = new TEntry('cod_peca');
        $id_cor   = new TDBCombo('id_cor', 'sample', 'Cor', 'id', 'descricao');
        $espessura   = new TEntry('espessura');
        $data_evento   = new TEntry('data_evento');
        $hora   = new TEntry('hora');
        $descricao   = new TEntry('descricao');
      
        
        

        
        // add the form fields
        $this->form->addFields( [new TLabel('ID')],    [$id] );
        $this->form->addFields( [new TLabel('Status da peça', 'red')],  [$id_status_peca] );
        $this->form->addFields( [new TLabel('Cód do pedido', 'red')],  [$id_pedido] );
        $this->form->addFields( [new TLabel('Tipo', 'blue')],  [$tipo_peca] );
        $this->form->addFields( [new TLabel('Cód da peça', 'red')],  [$cod_peca] );
        $this->form->addFields( [new TLabel('Cod do vidro', 'red')],  [$id_cor] );
        $this->form->addFields( [new TLabel('Espessura', 'red')],  [$espessura] );
        $this->form->addFields( [new TLabel('Data', 'blue')],  [$data_evento] );
        $this->form->addFields( [new TLabel('Hora', 'blue')],  [$hora] );
        $this->form->addFields( [new TLabel('Descrição', 'red')],  [$descricao] );
        
        $id_status_peca->addValidation('id_status_peca', new TRequiredValidator);
        $id_pedido->addValidation('id_pedido', new TRequiredValidator);
        $descricao->addValidation('descricao', new TRequiredValidator);
        $cod_peca->addValidation('cod_peca', new TRequiredValidator);
        $id_cor->addValidation('id_cor', new TRequiredValidator);

        
        
        // define the form actions
        $this->form->addAction( 'Save', new TAction([$this, 'onSave']), 'fa:save green');
        $this->form->addActionLink( 'Clear',new TAction([$this, 'onClear']), 'fa:eraser red');
        
        // make id not editable
        $id->setEditable(FALSE);
        
        // create the datagrid
        $this->datagrid = new BootstrapDatagridWrapper(new TDataGrid);
        $this->datagrid->width = '100%';
        
        // add the columns
        $column_id    = new TDataGridColumn('id', 'Id', 'right', '5%');        
        $column_id_status_peca = new TDataGridColumn('StatusPeca->status', 'Status', 'left', '15%');
        $column_id_pedido  = new TDataGridColumn('Pedido->cod_pedido', 'Cód. do pedido', 'left', '5%');
        $column_tipo_peca  = new TDataGridColumn('tipo_peca', 'Tipo', 'left', '10%');
        $column_cod_peca  = new TDataGridColumn('cod_peca', 'Cód. da peça', 'left', '5%');
        $column_id_cor  = new TDataGridColumn('Cor->descricao', 'Cor', 'left', '5%');
        $column_espessura  = new TDataGridColumn('espessura', 'Espess.', 'left', '5%');
        $column_data_evento  = new TDataGridColumn('data_evento', 'Data', 'left', '10%');
        $column_hora  = new TDataGridColumn('hora', 'Hora', 'left', '10%');
        $column_descricao  = new TDataGridColumn('descricao', 'Descricao', 'left', '30%');
       

        
        $this->datagrid->addColumn($column_id);
        $this->datagrid->addColumn($column_id_status_peca);
        $this->datagrid->addColumn($column_id_pedido);
        $this->datagrid->addColumn($column_tipo_peca);
        $this->datagrid->addColumn($column_cod_peca);
        $this->datagrid->addColumn($column_id_cor);
        $this->datagrid->addColumn($column_espessura);
        $this->datagrid->addColumn($column_data_evento);
        $this->datagrid->addColumn($column_hora);
        $this->datagrid->addColumn($column_descricao);
      
      

        
        $column_id->setAction( new TAction([$this, 'onReload']),   ['order' => 'id']);
        //$col_nome->setAction( new TAction([$this, 'onReload']), ['order' => 'nome']);
        //$col_cnpj->setAction( new TAction([$this, 'onReload']), ['order' => 'cnpj']);
        //$col_responsavel->setAction( new TAction([$this, 'onReload']), ['order' => 'responsavel']);
        //$col_email->setAction( new TAction([$this, 'onReload']), ['order' => 'email']);
        //$col_telefone1->setAction( new TAction([$this, 'onReload']), ['order' => 'telefone1']);
        //$col_telefone2->setAction( new TAction([$this, 'onReload']), ['order' => 'telefone2']);
        //$col_endereco->setAction( new TAction([$this, 'onReload']), ['order' => 'endereco']);
        //$col_uf->setAction( new TAction([$this, 'onReload']), ['order' => 'uf']);
        //$col_cidade->setAction( new TAction([$this, 'onReload']), ['order' => 'cidade']);
        
        // define row actions
        $action1 = new TDataGridAction([$this, 'onEdit'],   ['key' => '{id}'] );
        $action2 = new TDataGridAction([$this, 'onDelete'], ['key' => '{id}'] );
        
        $this->datagrid->addAction($action1, 'Edit',   'far:edit blue');
        $this->datagrid->addAction($action2, 'Delete', 'far:trash-alt red');
        
        // create the datagrid model
        $this->datagrid->createModel();
        
        // wrap objects inside a table
        $vbox = new TVBox;
        $vbox->style = 'width: 100%';
        $vbox->add(new TXMLBreadCrumb('menu.xml', __CLASS__));
        $vbox->add($this->form);
        $vbox->add(TPanelGroup::pack('', $this->datagrid));
        
        // pack the table inside the page
        parent::add($vbox);
    }
}