<?php
/**
 * StandardFormDataGridView
 *
 * @version    1.0
 * @package    samples
 * @subpackage tutor
 * @author     Pablo Dall'Oglio
 * @copyright  Copyright (c) 2006 Adianti Solutions Ltd. (http://www.adianti.com.br)
 * @license    http://www.adianti.com.br/framework-license
 */
class CadastroPedido extends TPage
{
    protected $form;      // form
    protected $datagrid;  // datagrid
    protected $loaded;
    protected $pageNavigation;  // pagination component
    
    // trait with onSave, onEdit, onDelete, onReload, onSearch...
    use Adianti\Base\AdiantiStandardFormListTrait;
    
    /**
     * Class constructor
     * Creates the page, the form and the listing
     */
    public function __construct()
    {
        parent::__construct();
        
        $this->setDatabase('sample'); // define the database
        $this->setActiveRecord('Pedido'); // define the Active Record
        $this->setDefaultOrder('id', 'asc'); // define the default order
        $this->setLimit(-1); // turn off limit for datagrid
        
        // create the form
        $this->form = new BootstrapFormBuilder('form_pedido');
        $this->form->setFormTitle(('Cadastro de Pedidos'));
        
        // create the form fields
        $id     = new TEntry('id');
        $id_cliente   = new TDBCombo('id_cliente', 'sample', 'Cliente', 'id', 'nome');  
        $cod_pedido   = new TEntry('cod_pedido');
        $qdt_pecas   = new TEntry('qdt_pecas');
        //$id_status_pedido   = new TEntry('id_status_pedido');
        $id_status_pedido   = new TDBCombo('id_status_pedido', 'sample', 'StatusPedido', 'id', 'status');
        

        
        // add the form fields
        $this->form->addFields( [new TLabel('ID')],    [$id] );
        $this->form->addFields( [new TLabel('Nome da empresa', 'red')],  [$id_cliente] );       
        $this->form->addFields( [new TLabel('Código do pedido', 'red')],  [$cod_pedido] );
        $this->form->addFields( [new TLabel('Qdt peças(1)', 'red')],  [$qdt_pecas] );
        $this->form->addFields( [new TLabel('Status do pedido', 'red')],  [$id_status_pedido] );
        
        $id_cliente->addValidation('id_cliente', new TRequiredValidator);       
        $cod_pedido->addValidation('cod_pedido', new TRequiredValidator);
        $qdt_pecas->addValidation('qdt_pecas', new TRequiredValidator);
        $id_status_pedido->addValidation('id_status_pedido', new TRequiredValidator);
        
        // define the form actions
        $this->form->addAction( 'Save', new TAction([$this, 'onSave']), 'fa:save green');
        $this->form->addActionLink( 'Clear',new TAction([$this, 'onClear']), 'fa:eraser red');
        
        // make id not editable
        $id->setEditable(FALSE);
        
        // create the datagrid
        $this->datagrid = new BootstrapDatagridWrapper(new TDataGrid);
        $this->datagrid->width = '100%';
        
        // add the columns
        $column_id    = new TDataGridColumn('id', 'Id', 'right', '5%');        
        $column_id_cliente = new TDataGridColumn('Cliente->nome', 'Nome do cliente', 'left', '25%');       
        $column_cod_pedido  = new TDataGridColumn('cod_pedido', 'Cód. Pedido', 'left', '20%');
        $column_qdt_pecas  = new TDataGridColumn('qdt_pecas', 'Qdt peças', 'left', '10%');
        $column_id_status_pedido  = new TDataGridColumn('StatusPedido->status', 'Status do pedido', 'left', '40%');
       

        
        $this->datagrid->addColumn($column_id);
        $this->datagrid->addColumn($column_id_cliente);        
        $this->datagrid->addColumn($column_cod_pedido);
        $this->datagrid->addColumn($column_qdt_pecas);
        $this->datagrid->addColumn($column_id_status_pedido);
      
      

        
        $column_id->setAction( new TAction([$this, 'onReload']),   ['order' => 'id']);
        //$col_nome->setAction( new TAction([$this, 'onReload']), ['order' => 'nome']);
        //$col_cnpj->setAction( new TAction([$this, 'onReload']), ['order' => 'cnpj']);
        //$col_responsavel->setAction( new TAction([$this, 'onReload']), ['order' => 'responsavel']);
        //$col_email->setAction( new TAction([$this, 'onReload']), ['order' => 'email']);
        //$col_telefone1->setAction( new TAction([$this, 'onReload']), ['order' => 'telefone1']);
        //$col_telefone2->setAction( new TAction([$this, 'onReload']), ['order' => 'telefone2']);
        //$col_endereco->setAction( new TAction([$this, 'onReload']), ['order' => 'endereco']);
        //$col_uf->setAction( new TAction([$this, 'onReload']), ['order' => 'uf']);
        //$col_cidade->setAction( new TAction([$this, 'onReload']), ['order' => 'cidade']);
        
        // define row actions
        $action1 = new TDataGridAction([$this, 'onEdit'],   ['key' => '{id}'] );
        $action2 = new TDataGridAction([$this, 'onDelete'], ['key' => '{id}'] );
        
        $this->datagrid->addAction($action1, 'Edit',   'far:edit blue');
        $this->datagrid->addAction($action2, 'Delete', 'far:trash-alt red');
        
        // create the datagrid model
        $this->datagrid->createModel();
        
        // wrap objects inside a table
        $vbox = new TVBox;
        $vbox->style = 'width: 100%';
        $vbox->add(new TXMLBreadCrumb('menu.xml', __CLASS__));
        $vbox->add($this->form);
        $vbox->add(TPanelGroup::pack('', $this->datagrid));
        
        // pack the table inside the page
        parent::add($vbox);
    }
}